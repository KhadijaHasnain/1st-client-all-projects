from unittest import TestCase
from matchpredictor.matchresults.result import Outcome, Fixture, Scenario
from matchpredictor.model.model_provider import ModelProvider, Model
from matchpredictor.predictors.predictor import Prediction, Predictor, InProgressPredictor

# Assuming you have already defined the AccuratePredicate class

class TestModelProvider(TestCase):
    accurate_predictor = AccuratePredicate()
    accurate_model = Model(
        name="accurate model",
        predictor=accurate_predictor
    )

    provider = ModelProvider([accurate_model])

    def test_get_predictor(self):
        self.assertEqual(self.provider.get_predictor("accurate model"), self.accurate_predictor)
        self.assertIsNone(self.provider.get_predictor("not there model"))

    def test_get_in_progress_predictor(self):
        self.assertIsNone(self.provider.get_in_progress_predictor("accurate model"))
        self.assertIsNone(self.provider.get_in_progress_predictor("not there model"))

    def test_list(self):
        self.assertEqual(self.provider.list(), [self.accurate_model])
