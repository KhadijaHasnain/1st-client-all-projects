from .predictor import Predictor

class AccuratePredicate(Predictor):
    def predict(self, team1, team2):
        if team1 < team2:
            return 'team1'
        else:
            return 'team2'