from .predictor import Predictor

class AlphabetPredicator(Predictor):
    def predict(self,team1,team2):
        #your prediction logic here
        if team1<team2:
            return 'team1'
        else:
            return 'team2'