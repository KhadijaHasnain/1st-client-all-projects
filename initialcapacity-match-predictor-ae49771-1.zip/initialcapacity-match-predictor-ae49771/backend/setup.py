from distutils.core import setup

setup(name='Match predictor',
      version='0.0.1',
      description='Match predictor',
      packages=['matchpredictor'],
      )
