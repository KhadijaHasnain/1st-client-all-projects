from matchpredictor.league_predictor_report import predictor_report_for

predictor_report_for('Barclays Premier League', 2021)
predictor_report_for('English League Championship', 2021)
predictor_report_for('Italy Serie A', 2021)
