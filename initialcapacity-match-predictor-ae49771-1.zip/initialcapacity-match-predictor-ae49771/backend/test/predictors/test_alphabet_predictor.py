from backend.matchpredictor.predictors import alpha_predictor
from backend.test import PredictorTestMixin

class TestAlphabetPredictor(PredictorTestMixin):
    def creat_predictor(self):
        return alpha_predictor()
    
    def test_accuracy(self):
        self.assert_accracy_above(0.33)