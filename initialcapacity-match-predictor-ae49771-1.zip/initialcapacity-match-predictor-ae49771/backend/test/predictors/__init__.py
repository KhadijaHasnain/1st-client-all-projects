csv_location = 'https://projects.fivethirtyeight.com/soccer-api/club/spi_matches.csv'
