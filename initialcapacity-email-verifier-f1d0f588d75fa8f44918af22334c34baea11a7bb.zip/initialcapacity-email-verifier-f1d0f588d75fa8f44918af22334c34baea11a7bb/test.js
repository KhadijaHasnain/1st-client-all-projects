import http from 'k6/http';
import { check } from 'k6';

export const options = {
  vus: 10,
  duration: '30s',
};

export default function () {
  const payload = JSON.stringify({ email: 'test@example.com' });
  const headers = { 'Content-Type': 'application/json' };

  const response = http.post('http://localhost:8081/request-registration', payload, { headers });

  check(response, {
    'HTTP status is 204': (r) => r.status === 204,
  });
}
