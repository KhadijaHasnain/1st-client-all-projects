package io.milk.client

data class PurchaseTask(val id: Long, val name: String, val amount: Int)