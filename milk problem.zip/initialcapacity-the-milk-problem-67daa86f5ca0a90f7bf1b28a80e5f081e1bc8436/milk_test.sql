-- Create the user 'milk' with password 'milk'
CREATE USER milk WITH PASSWORD 'milk';

-- Grant necessary privileges to the user 'milk'
ALTER USER milk CREATEDB;

-- Create the database 'milk_test' owned by the user 'milk'
CREATE DATABASE milk_test OWNER milk;