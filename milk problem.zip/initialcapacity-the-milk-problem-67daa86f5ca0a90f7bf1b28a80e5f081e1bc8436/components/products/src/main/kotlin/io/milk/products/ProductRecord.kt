package io.milk.products

data class ProductRecord(val id: Long, val name: String, var quantity: Int)